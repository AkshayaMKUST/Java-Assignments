package com.employee.Employee.controller;

import com.employee.Employee.entity.Employee;
import com.employee.Employee.exception.EmployeeAlreadyExists;
import com.employee.Employee.exception.EmployeeNotFound;
import com.employee.Employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping()
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @PostMapping()
    public ResponseEntity<List<Employee>> createEmployee(@RequestBody @Valid List<Employee> employee) throws EmployeeAlreadyExists {
        List<Employee> createdEmployees = employeeService.createEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployees);
    }

    @GetMapping
    public ResponseEntity<List<Employee>> fetchEmployees() {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(employeeService.fetchEmployees());
    }

    @GetMapping("{employeeId}")
    public ResponseEntity<Employee> fetchEmployeeById(@PathVariable Integer employeeId) throws EmployeeNotFound {
        return ResponseEntity.ok(employeeService.fetchEmployeeById(employeeId));
    }

    @PutMapping()
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) throws EmployeeNotFound {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(employeeService.updateEmployee(employee));
    }

    @DeleteMapping("{employeeId}")
    public String deleteEmployee(@PathVariable Integer employeeId) {
        employeeService.deleteEmployee(employeeId);
        return "Employee deleted successfully";
    }
    @GetMapping("find/{skill}")
    public ResponseEntity<String> findEmployeeBySkill(@PathVariable String skill) {
        List<Employee> employees = employeeService.fetchEmployees();
        List<String> employeesWithSkill = findEmployeeWithSkill(employees, skill);
        if (!employeesWithSkill.isEmpty()) {
            return ResponseEntity.ok("Employees with " + skill + " skill found:"+employeesWithSkill);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No employees with " + skill + " skill found!");
        }
   }

    private List<String> findEmployeeWithSkill(List<Employee> employees, String skill) {
        return employees.stream()
                .filter(employee -> employee.getEmployeeSkills() != null && employee.getEmployeeSkills().contains(skill)).map(Employee::getEmployeeName)
                .collect(Collectors.toList());
    }

}
