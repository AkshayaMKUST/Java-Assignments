package com.employee.Employee.controller;

import com.employee.Employee.entity.Employee;
import com.employee.Employee.exception.EmployeeAlreadyExists;
import com.employee.Employee.exception.EmployeeNotFound;
import com.employee.Employee.repository.EmployeeRepository;
import com.employee.Employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@Validated
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @Autowired
    EmployeeRepository employeeRepository;

    @PostMapping()
    public ResponseEntity<List<Employee>> createEmployee( @RequestBody List<@Valid Employee> employee) throws EmployeeAlreadyExists {
        List<Employee> createdEmployees = employeeService.createEmployee(employee);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployees);
    }


    @GetMapping
    public ResponseEntity<List<Employee>> fetchEmployees() {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(employeeService.fetchEmployees());
    }

    @GetMapping("{employeeId}")
    public ResponseEntity<Employee> fetchEmployeeById(@PathVariable Integer employeeId) throws EmployeeNotFound {
        return ResponseEntity.ok(employeeService.fetchEmployeeById(employeeId));
    }

    @PutMapping()
    public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) throws EmployeeNotFound {
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(employeeService.updateEmployee(employee));
    }

    @DeleteMapping("{employeeId}")
    public String deleteEmployee(@PathVariable Integer employeeId) {
        employeeService.deleteEmployee(employeeId);
        return "Employee deleted successfully";
    }

    @GetMapping("find/{skill}")
    public ResponseEntity<String> findEmployeeBySkill(@PathVariable List<String> skill) {
        List<Employee> employees = employeeService.fetchEmployees();
        List<String> employeesWithSkill = findEmployeeWithSkill(employees, skill);
        if (!employeesWithSkill.isEmpty()) {
            return ResponseEntity.ok("Employees with " + skill + " skill found:" + employeesWithSkill);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No employees with " + skill + " skill found!");
        }
    }

    private List<String> findEmployeeWithSkill(List<Employee> employees, List<String> requiredSkills) {
        return employees.stream()
                .filter(employee -> employee.getEmployeeSkills() != null && employee.getEmployeeSkills().containsAll(requiredSkills))
                .map(Employee::getEmployeeName)
                .collect(Collectors.toList());
    }

    @GetMapping("total")
    public ResponseEntity<String> findTotalNumberOfEmployees() {
        List<Employee> employees = employeeService.fetchEmployees();
        long totalNumberOfEmployees = employees.stream().count();
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Total number of employees : " + totalNumberOfEmployees);
    }

    @GetMapping("department")
    public Map<String, List<String>> fetchEmployeesBasedOnDepartment() {
        List<Employee> employees = employeeService.fetchEmployees();
        return employees.stream().collect(Collectors.groupingBy(Employee::getEmployeeDepartment,
                Collectors.mapping(Employee::getEmployeeName, Collectors.toList())));
    }

    @GetMapping("totalSalary")
    public ResponseEntity<String> findTotalSalaryOfEmployees() {
        List<Employee> employees = employeeService.fetchEmployees();
        Optional<Integer> totalSalaryOfEmployees = employees.stream().map(Employee::getEmployeeSalary).reduce((x, y)->(x+y));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Total salary of employees : " + totalSalaryOfEmployees.get());
    }

    @GetMapping("totalSalaryOfDepartment")
    public Map<String, Integer> fetchSalaryBasedOnDepartment() {
        List<Employee> employees = employeeService.fetchEmployees();
        return employees.stream().collect(Collectors.groupingBy(Employee::getEmployeeDepartment,Collectors.summingInt(Employee::getEmployeeSalary)));
    }

    @GetMapping("sortAge")
    public List<Employee> sortEmployeesBasedOnAge(){
        List<Employee> employees = employeeService.fetchEmployees();
        return employees.stream().sorted(Comparator.comparing(Employee::getEmployeeAge)).toList();
    }

    @GetMapping("sortExperience")
    public List<Employee> sortEmployeesBasedOnExperience(){
        List<Employee> employees = employeeService.fetchEmployees();
        return employees.stream().sorted(Comparator.comparing(Employee::getEmployeeExperience)).toList();
    }
}
