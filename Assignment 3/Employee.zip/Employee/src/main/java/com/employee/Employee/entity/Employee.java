package com.employee.Employee.entity;

import jakarta.persistence.ElementCollection;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    @NotNull(message = "Employee ID must not be null")
    private Integer employeeId;

    @NotBlank(message = "Employee Name cannot be blank")
    @Size(min = 2, max = 50, message = "Employee Name should be between 2 and 50 characters")
    private String employeeName;

    @NotBlank(message = "Employee department cannot be blank")
    @Size(min = 2, max = 100, message = "Employee department must be between 2 and 100 characters")
    private String employeeDepartment;

    @ElementCollection
    private List<String> employeeSkills;
}
