package com.employee.Employee.entity;

import jakarta.persistence.ElementCollection;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
    @Id
    private Integer employeeId;
    private String employeeName;
    private Integer employeeAge;
    private String employeeDepartment;
    private Integer employeeExperience;
    private Integer employeeSalary;
    private Integer createdUserId;
    private String createdTimeStamp;

    @ElementCollection
    private List<String> employeeSkills;
}
