package org.example;

@FunctionalInterface
public interface Operation {
    double operate(double num1,double num2);
}
