package com.employee.Employee.service;
import com.employee.Employee.entity.Employee;
import com.employee.Employee.exception.EmployeeAlreadyExists;
import com.employee.Employee.exception.EmployeeNotFound;

import java.util.List;

public interface EmployeeService {
    List<Employee> createEmployee(List<Employee> employee) throws EmployeeAlreadyExists;
    List<Employee> fetchEmployees();
    Employee fetchEmployeeById(Integer employeeId) throws EmployeeNotFound;
    Employee updateEmployee(Employee employee) throws EmployeeNotFound;
    void deleteEmployee(Integer employeeId);

}
