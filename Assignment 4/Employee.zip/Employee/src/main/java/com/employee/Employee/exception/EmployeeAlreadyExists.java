package com.employee.Employee.exception;

public class EmployeeAlreadyExists extends Exception {
    public EmployeeAlreadyExists(String message) {
        super(message);
    }
}
