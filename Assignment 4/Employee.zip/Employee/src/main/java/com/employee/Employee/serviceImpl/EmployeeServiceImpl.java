package com.employee.Employee.serviceImpl;

import com.employee.Employee.entity.Employee;
import com.employee.Employee.exception.EmployeeAlreadyExists;
import com.employee.Employee.exception.EmployeeNotFound;
import com.employee.Employee.repository.EmployeeRepository;
import com.employee.Employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestHeader;

import java.time.LocalDate;
import java.util.*;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public List<Employee> createEmployee(@RequestHeader("userId") List<Employee> employees) throws EmployeeAlreadyExists {
        List<Employee> createdEmployees = new ArrayList<>();
        for(Employee employee : employees){
            try {
                Optional<Employee> employeeOptional = employeeRepository.findById(employee.getEmployeeId());
                if(employeeOptional.isPresent()){
                    throw new EmployeeAlreadyExists("Employee with the given id "+employee.getEmployeeId()+" already exists");
                }
                createdEmployees.add(employeeRepository.save(employee));
            } catch (EmployeeAlreadyExists ex) {
                System.err.println("Exception occurred: " + ex.getMessage());
            }
        }
        return createdEmployees;
    }
    @Override
    public List<Employee> fetchEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee fetchEmployeeById(Integer employeeId) throws EmployeeNotFound {
        Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
        if(employeeOptional.isEmpty()){
            throw new EmployeeNotFound("Employee with the given id does not exist");
        }
        return employeeOptional.get();

    }

    @Override
    public Employee updateEmployee(Employee employee) throws EmployeeNotFound {
        Optional<Employee> employeeOptional = employeeRepository.findById(employee.getEmployeeId());
        Employee existingEmployee = employeeOptional.orElseThrow(() -> new EmployeeNotFound("Employee with the given id does not exist"));
        existingEmployee.setEmployeeName(employee.getEmployeeName());;
        existingEmployee.setEmployeeAge(employee.getEmployeeAge());
        existingEmployee.setEmployeeDepartment(employee.getEmployeeDepartment());
        existingEmployee.setEmployeeExperience(employee.getEmployeeExperience());
        existingEmployee.setEmployeeSalary(employee.getEmployeeSalary());
        existingEmployee.setEmployeeSkills(employee.getEmployeeSkills());
        return employeeRepository.save(existingEmployee);
    }

    @Override
    public void deleteEmployee(Integer employeeId) {
        employeeRepository.deleteById(employeeId);
    }
}
